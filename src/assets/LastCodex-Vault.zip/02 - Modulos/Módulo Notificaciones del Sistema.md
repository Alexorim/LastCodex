---
title: "Módulo Notificaciones del Sistema"
type: module
tags:
  - "#modulo"
  - "#notificaciones"
  - "#recordatorios"
  - "#capacitor"
version: 1.4.5
created: 2026-09-29
---

# 🔔 Módulo Notificaciones del Sistema (Push & Local Alerts)

El **Módulo de Notificaciones** proporciona un sistema de alertas programadas que se integran directamente con la bandeja y la barra de notificaciones del sistema operativo Android y la Web Notification API.

Conexiones:
- Nodo Padre: [[00 - Nodo Central (MOC) - LastCodex]]
- Servicio Central: [[NotificationsService]]
- Vistas Emisoras: [[CalendarPage - Calendario de Materiales]], [[TowersPage - Torres Celestiales]]
- Configuración Global: [[SettingsPage - Configuración]]
- Integración Nativa: [[Plataforma Android y Capacitor]]

---

## 📱 Plantillas de Notificación Oficiales

Las notificaciones están redactadas y diseñadas para mostrarse con máxima claridad en la barra de estado y el panel expandido del celular:

### 1. Notificación de Material Disponible
Se activa cuando el jugador programa un recordatorio para un material desde el calendario:
```text
LastResources • ahora
¡Material Disponible: Pure Runestone!
El material Pure Runestone ya está disponible en el Gremio de Espira.
```
- **Estructura del Título**: `¡Material Disponible: {material}!`
- **Estructura del Cuerpo**: `El material {material} ya está disponible en el {gremio}.`

### 2. Notificación de Torre al Piso 50
Se activa cuando una torre celestial alcanza su altura máxima de farmeo:
```text
LastResources • ahora
¡Torre de Selene al Piso 50!
La Torre de Selene acaba de alcanzar su punto máximo (Piso 50).
¡Es momento de farmear!
```
- **Estructura del Título**: `¡{nombre_de_torre} al Piso 50!`
- **Estructura del Cuerpo**: `La {nombre_de_torre} acaba de alcanzar su punto máximo (Piso 50).\n¡Es momento de farmear!`

---

## ⚙️ Arquitectura Técnica

1. **Plugin Nativo**: Utiliza `@capacitor/local-notifications` para interactuar con el `NotificationManager` de Android sin requerir servidores externos ni servicios de terceros.
2. **Canales de Notificación (Notification Channels)**: Canal registrado con alta prioridad (`high importance`), sonido predeterminado del sistema y vibración activada.
3. **Persistencia y Cancelación**: Cada recordatorio cuenta con un identificador numérico único generado determinísticamente para permitir reprogramar o cancelar recordatorios sin duplicidades.
4. **Respeto a la Privacidad**: Totalmente local; no recopila identificadores de dispositivo, tokens push externos ni datos de telemetría.

---

## 🔗 Sinapsis Relacionadas
- Ver servicio de notificaciones: [[NotificationsService]]
- Ver calendario: [[CalendarPage - Calendario de Materiales]]
- Ver torres: [[TowersPage - Torres Celestiales]]
- Ver ajustes: [[SettingsPage - Configuración]]
