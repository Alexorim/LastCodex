---
title: "Módulo Torres Celestiales"
type: module
tags:
  - "#modulo"
  - "#torres"
  - "#celestial"
  - "#titanes"
version: 1.4.5
created: 2026-09-29
---

# 🗼 Módulo Torres Celestiales (Celestial Towers)

El **Módulo Torres Celestiales** permite a los jugadores de *Orna: The GPS RPG* y *Hero of Aethric* monitorear la rotación semanal y el crecimiento progresivo de pisos de las 5 torres celestiales (Selene, Prometeo, Eos, Oceanus y Themis).

Conexiones:
- Nodo Padre: [[00 - Nodo Central (MOC) - LastCodex]]
- Servicio Central: [[TowersService]]
- Notificaciones: [[NotificationsService]]
- Vistas Asociadas: [[TowersPage - Torres Celestiales]], [[CodexPage - Explorador del Códice]]
- Ajustes y Recordatorios: [[SettingsPage - Configuración]]

---

## 🏛️ Las 5 Torres Celestiales y sus Titanes

1. **Torre de Selene** (Titan Selene) — Clave para clases celestiales mágicas e invocadores.
2. **Torre de Prometeo** (Titan Prometheus) — Foco en poder físico y armaduras pesadas.
3. **Torre de Eos** (Titan Eos) — Esencia de la aurora y daño elemental.
4. **Torre de Oceanus** (Titan Oceanus) — Dominio acuático y mitigación de daño.
5. **Torre de Themis** (Titan Themis) — Juicio divino, balance y runas protectoras.

---

## ⚙️ Características Técnicas y Funcionalidades

### 1. Cronograma y Progresión de Pisos (Floor Growth Timeline)
- Las torres incrementan su altura en cada ciclo de reseteo hasta llegar a su límite máximo: **50 pisos**.
- El módulo calcula dinámicamente cuántos pisos tendrá cada torre en las fechas venideras y presenta una línea de tiempo interactiva dentro del modal de detalle de la torre.

### 2. Acceso Directo al Códice ("Ver en el Códice")
- Al inspeccionar una torre, el jugador dispone de un acceso directo para abrir inmediatamente la ficha oficial del titán correspondiente en [[CodexPage - Explorador del Códice]], mostrando sus estadísticas, resistencias, debilidades y recompensas.

### 3. Recordatorios y Notificaciones al Piso 50
- Integración con [[NotificationsService]] para programar recordatorios locales en el dispositivo móvil:
  - Recordatorio manual al tocar el botón de campana/reloj en la tarjeta de la torre.
  - Alerta automática global configurada desde [[SettingsPage - Configuración]] para avisar en la barra de notificaciones del celular en el momento exacto en que cualquier torre alcance los 50 pisos:
  ```text
  LastResources • ahora
  ¡Torre de Selene al Piso 50!
  La Torre de Selene acaba de alcanzar su punto máximo (Piso 50).
  ¡Es momento de farmear!
  ```

### 4. Limpieza Visual y Ergonomía
- Interfaz pulida sin textos redundantes de elementos bajo el título de la torre, priorizando el conteo de pisos, el tiempo restante y el estado de rotación.

---

## 🔗 Sinapsis Relacionadas
- Ver servicio de torres: [[TowersService]]
- Ver vista de torres: [[TowersPage - Torres Celestiales]]
- Ver servicio de notificaciones: [[NotificationsService]]
- Ver explorador del códice: [[CodexPage - Explorador del Códice]]
