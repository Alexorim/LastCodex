---
title: "Módulo Legal y Cumplimiento DMCA"
type: module
tags:
  - "#modulo"
  - "#legal"
  - "#privacidad"
  - "#dmca"
  - "#copyright"
version: 1.4.5
created: 2026-09-29
---

# ⚖️ Módulo Legal y Cumplimiento DMCA

El **Módulo Legal y de Cumplimiento DMCA** define las políticas de uso, protección de propiedad intelectual, exención de responsabilidad y privacidad de **LastResources**.

Conexiones:
- Nodo Padre: [[00 - Nodo Central (MOC) - LastCodex]]
- Vista Asociada: [[LegalPage - Aviso Legal y Privacidad]]
- Códice y Fuentes: [[CodexPage - Explorador del Códice]]
- Acceso: Accesible desde el footer de la aplicación y desde [[SettingsPage - Configuración]].

---

## 🛡️ Pilares de Protección Legal

### 1. Naturaleza Comunitaria Sin Fines de Lucro
- LastResources es un proyecto comunitario independiente, libre de costos, sin publicidad invasiva y desarrollado por y para fans de los juegos creados por **Northern Forge Studios**.

### 2. Reconocimiento de Marcas Comerciales
- *Orna: The GPS RPG* y *Hero of Aethric* son marcas registradas y propiedad de **Northern Forge Studios**.
- LastResources declara de manera explícita que **no está respaldado, patrocinado, afiliado ni asociado formalmente** con Northern Forge Studios.

### 3. Atribución de Datos Públicos en el Códice
- La información de ítems, monstruos, hechizos y habilidades contenida en el Códice se recopila de fuentes públicas abiertas del juego con fines informativos y educativos para la comunidad de jugadores.

### 4. Privacidad Absoluta y Cero Rastreo
- La aplicación y la web **no recopilan ni procesan datos personales**, no almacenan cookies de seguimiento de terceros ni utilizan redes publicitarias comerciales.
- Toda la configuración (favoritos, tema, recordatorios, idioma) se almacena exclusivamente en el almacenamiento local del dispositivo (`LocalStorage` e `IndexedDB`).

### 5. Procedimiento Safe Harbor y Aviso DMCA (Takedown)
- En estricto cumplimiento con el protocolo de puerto seguro (Safe Harbor) de la DMCA y directivas de propiedad intelectual, cualquier titular de derechos que requiera la modificación o retiro de contenido puede enviar una notificación formal al canal designado:
  - 📧 Correo de contacto DMCA: `guygamerxd@gmail.com`
  - Tiempo de respuesta comprometido: expedito tras verificación.

---

## 🔗 Sinapsis Relacionadas
- Ver página legal: [[LegalPage - Aviso Legal y Privacidad]]
- Ver explorador del códice: [[CodexPage - Explorador del Códice]]
- Ver panel de ajustes: [[SettingsPage - Configuración]]
