---
title: "Módulo Calculadora de Pruebas de Gremios"
type: module
tags:
  - "#modulo"
  - "#proofs"
  - "#calculadora"
  - "#gremios"
  - "#materiales"
status: active
version: 1.4.6
created: 2026-09-29
---

# 🪙 Módulo Calculadora de Pruebas de Gremios

El **Módulo de Calculadora de Pruebas** (`ProofsModule` / `ProofsPage`) es la herramienta especializada de conversión y estimación de costes entre materiales y monedas oficiales de todos los gremios en **Orna: The GPS RPG** y **Hero of Aethric**.

Conexiones:
- Nodo Padre: [[00 - Nodo Central (MOC) - LastCodex]]
- Servicio Central: [[ProofsService]]
- Página de Presentación: [[ProofsPage - Calculadora de Pruebas]]
- Módulo Vinculado: [[Módulo Torres Celestiales]]
- Registro de Versión: [[v1.4.6 - Calculadora Oficial de Pruebas y Optimizaciones Móviles]]

---

## 🎯 Propósito y Capacidades

Permite a los jugadores calcular exactamente cuántas pruebas o monedas de cada gremio necesitan para adquirir cualquier material del juego, o a la inversa, cuántos materiales pueden canjear con su saldo actual de pruebas.

### 📐 Fórmulas Matemáticas Oficiales

1. **Tasa Base del Material (`baseRate`)**:
   $$ \text{Tasa Base} = (\text{Tier} \times 10) + (\text{Rareza Multiplicador} \times 5) $$
   - Multiplicadores de rareza:
     - Común: `0`
     - Raro: `1`
     - Afamado: `2`
     - Legendario / Hito: `3`

2. **Cálculo de Pruebas Requeridas**:
   $$ \text{Coste} = \left\lceil \frac{\text{Cantidad Materiales} \times \text{Ratio Gremio} \times \text{Tasa Base}}{100} \right\rceil $$

3. **Cálculo Inverso (Materiales adquiribles con $N$ pruebas)**:
   $$ \text{Materiales Canjeables} = \left\lfloor \frac{\text{Pruebas} \times 100}{\text{Ratio Gremio} \times \text{Tasa Base}} \right\rfloor $$

---

## 🏛️ Gremios y Monedas Soportadas

| Moneda | Gremio Oficial | Ratio Multiplicador |
| :--- | :--- | :--- |
| **Prueba de Monumento** (*Proof of Monument*) | Gremio de Monumentos | `x10` |
| **Prueba de Angustia** (*Proof of Anguish*) | Círculo de la Angustia | `x1` |
| **Prueba de Entrenamiento** (*Proof of Sparring*) | Hojas de Destreza (Blades of Finesse) | `x4` |
| **Prueba de Derribo** (*Proof of Felling*) | Gremio de Tala | `x20` |
| **Fragmento Profundo** (*Deepshard*) | Mazmorras Profundas | `x20` |
| **Prueba de Memoria** (*Proof of Memory*) | Gremio de la Memoria | `x2` |
| **Coral** (*Coral*) | Gremio del Coral | `x20` |
| **Prueba de Distancia** (*Proof of Distance*) | Gremio de Espeleología | `x20` |
| **Pruebas Titánicas** (*Prometheus, Selene, etc.*) | Talleres de los Titanes | Variables según torre |

---

## 📱 Diseño y Filosofía UI

- **Filosofía 2 Columnas Móvil**: Tarjetas ultra compactas de 2 por fila enfocadas en el logo del gremio y la cantidad requerida.
- **Sin preselección forzada**: Muestra costes base en `0 requeridos` de inmediato sin forzar la apertura del buscador.
- **Acceso rápido desde Inicio**: Botón dedicado en el header de [[HomePage - Forecast Hoy y Mañana]] junto al botón de Eventos.
