---
title: "Módulo Mapa Interactivo de Ciudades y Marcadores"
type: module
tags:
  - "#modulo"
  - "#mapa"
  - "#ciudades"
  - "#leaflet"
version: 1.4.5
created: 2026-09-29
---

# 🗺️ Módulo Mapa Interactivo de Ciudades y Marcadores

El **Módulo de Mapa Interactivo** integra una cartografía visual completa del mundo de juego de *Aethric* y *Orna*, permitiendo a los jugadores explorar territorios, ubicar ciudades, puestos de avanzada, santuarios, mazmorras y puntos de interés geoespaciales.

Conexiones:
- Nodo Padre: [[00 - Nodo Central (MOC) - LastCodex]]
- Vista Asociada: [[MapPage - Mapa Interactivo]]
- Acceso: Disponible desde [[SettingsPage - Configuración]] y navegación principal.

---

## 🧭 Características del Visor de Mapa

### 1. Motor Cartográfico Liviano
- Renderizado interactivo basado en mapas de teselas (*tile layers*) optimizados para bajo consumo de memoria y ancho de banda en dispositivos móviles y web.
- Soporte para gestos táctiles de pellizcar para hacer zoom (*pinch-to-zoom*), arrastre fluido y doble toque.

### 2. Filtros de Marcadores por Categoría
- Botón HUD flotante en pantalla con menú emergente (*popover*) que permite activar o desactivar capas de marcadores:
  - 🏙️ **Ciudades y Poblados** (*Cities*)
  - 🗝️ **Mazmorras y Criptas** (*Dungeons*)
  - ⛩️ **Santuarios y Monumentos** (*Shrines & Monuments*)
  - ⚔️ **Puntos de Interés y Gremios** (*Guilds & Wayvessels*)

### 3. Comportamiento Inteligente por Defecto
- **Optimización de Entrada**: Al ingresar al mapa, únicamente se encuentra activo por defecto el filtro de **Ciudades**, mientras que las demás categorías permanecen desactivadas.
- Esto evita saturación visual en la pantalla del móvil, acelera el renderizado inicial y previene caídas de fotogramas por sobrecarga de nodos en el DOM.

### 4. Escalamiento Dinámico de Marcadores
- Los pines y sprites de las ciudades y ubicaciones se ajustan dinámicamente según el nivel de zoom actual (`zoom level`), evitando que los iconos desaparezcan o se vuelvan ilegibles al alejar la cámara.

---

## 🔗 Sinapsis Relacionadas
- Ver página del mapa: [[MapPage - Mapa Interactivo]]
- Ver panel de configuración: [[SettingsPage - Configuración]]
