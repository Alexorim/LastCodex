# 🧠 Red Neuronal de Documentación — LastResources

Bóveda de conocimiento (**Obsidian Vault**) oficial de **LastResources** (anteriormente *LastCodex* / *OrnaForecast*).

## 🚀 Cómo abrir en Obsidian
1. Abre **Obsidian**.
2. Selecciona **"Abrir carpeta como bóveda" (Open folder as vault)**.
3. Elige la carpeta raíz de este repositorio (`lastcodex-obsidian`).
4. Abre la **Vista de Grafo** (`Ctrl + G`) para explorar la red neuronal interactiva de sinapsis.
5. Puedes comenzar la navegación desde `00 - Nodo Central (MOC) - LastCodex.md`.

## 📂 Estructura de Nodos
- **`00 - Nodo Central (MOC)`**: Nexo central de sinapsis interactivas.
- **`01 - General/`**: Visión, versiones (`v1.4.5`), arquitectura multicapa y stack tecnológico.
- **`02 - Modulos/`**: Forecast de gremios, torres celestiales, códice offline, mapa interactivo, notificaciones push, blindaje legal/DMCA, rastreador de eventos y configuración.
- **`03 - Servicios/`**: Lógica reactiva (`NotificationsService`, `TowersService`, `CodexService`, `MaterialsService`, `TimerService`, `SettingsService`, `BackButtonService`).
- **`04 - Paginas/`**: Vistas (`HomePage`, `TowersPage`, `CalendarPage`, `MapPage`, `SearchPage`, `CodexPage`, `CodexClassesPage`, `EventsPage`, `LegalPage`, `SettingsPage`).
- **`05 - Modelos/`**: Tipos TypeScript e interfaces de datos.
- **`06 - Plataformas/`**: Android (`com.lastresources.app`), Desktop (Electron) y Web (PWA / Vercel).
- **`07 - Scripts/`**: Automatización de APKs (`lastcodex_stable.apk`), generador de iconos y web scraping.
- **`08 - Utilidades/`**: Canvas gráfico, internacionalización (22 idiomas) y sprites.
- **`09 - Actualizaciones/`**: Changelog maestro con historial exhaustivo de versiones desde v1.0.0 hasta **v1.4.5**.

## 🔗 Repositorio Principal
- Código fuente: [LastCodex / LastResources en GitHub](https://github.com/Alexorim/LastCodex)
