---
title: "NotificationsService"
type: service
tags:
  - "#servicio"
  - "#notificaciones"
  - "#alertas"
  - "#capacitor"
version: 1.4.5
created: 2026-09-29
---

# 🔔 NotificationsService (`notifications.service.ts`)

`NotificationsService` es el servicio encargado de orquestar los recordatorios locales y despachar notificaciones a la barra de estado del sistema operativo en Android mediante Capacitor y a través de Notification API en navegadores web compatibles.

Conexiones:
- Nodo Padre: [[00 - Nodo Central (MOC) - LastCodex]]
- Módulo: [[Módulo Notificaciones del Sistema]]
- Vistas Consumidoras: [[CalendarPage - Calendario de Materiales]], [[TowersPage - Torres Celestiales]], [[SettingsPage - Configuración]]
- Servicios Hermanos: [[TowersService]], [[MaterialsService]]

---

## ⚙️ Características Técnicas

1. **Canal Dedicado en Android (`NotificationChannel`)**:
   - `id`: `lastresources_alerts`
   - `name`: `Alertas LastResources`
   - `importance`: `5` (High / Alta prioridad con sonido y vibración)
2. **Generación Determinística de IDs**:
   - Para evitar duplicación o colisiones entre recordatorios de materiales y torres, genera hashes enteros reproducibles para cada clave única (`materialName` o `towerKind`).
3. **Persistencia en LocalStorage**:
   - Claves de almacenamiento:
     - `lastresources_material_reminders`
     - `lastresources_tower_reminders`
     - `lastresources_all_towers_50_notify`

---

## 🌊 Métodos Principales

| Método | Retorno | Descripción |
| :--- | :--- | :--- |
| `requestPermissions()` | `Promise<boolean>` | Solicita al usuario permisos del sistema para emitir notificaciones. |
| `scheduleMaterialReminder(materialName, targetDate, displayName?, guildName?)` | `Promise<boolean>` | Programa un recordatorio para cuando el material rota en la tienda de un gremio. Formatea el mensaje con el template oficial: `¡Material Disponible: {material}!` en el `{gremio}`. |
| `cancelMaterialReminder(materialName)` | `Promise<void>` | Cancela la notificación programada para dicho material. |
| `isMaterialScheduled(materialName)` | `boolean` | Verifica si el material ya cuenta con un recordatorio activo. |
| `scheduleTower50Reminder(kind, towerTitle, targetDate)` | `Promise<boolean>` | Programa alerta para el instante exacto en que la torre celestial alcanza el Piso 50: `¡{Torre} al Piso 50!`. |
| `cancelTowerReminder(kind)` | `Promise<void>` | Cancela el recordatorio para la torre especificada. |
| `isTowerScheduled(kind)` | `boolean` | Comprueba si la torre tiene programado aviso de piso 50. |
| `toggleAllTowers50Alert(enable, towersList)` | `Promise<boolean>` | Activa o desactiva de forma masiva los recordatorios para todas las torres que alcanzarán el piso 50 (usado desde Settings). |

---

## 🔗 Sinapsis Relacionadas
- Ver módulo de notificaciones: [[Módulo Notificaciones del Sistema]]
- Ver servicio de torres: [[TowersService]]
- Ver calendario: [[CalendarPage - Calendario de Materiales]]
- Ver ajustes: [[SettingsPage - Configuración]]
