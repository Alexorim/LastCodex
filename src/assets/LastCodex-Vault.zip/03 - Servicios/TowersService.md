---
title: "TowersService"
type: service
tags:
  - "#servicio"
  - "#torres"
  - "#celestial"
  - "#algoritmo"
version: 1.4.5
created: 2026-09-29
---

# 🗼 TowersService (`towers.service.ts`)

`TowersService` encapsula el modelo matemático, la sincronización de rotación y las proyecciones futuras de altura de las 5 Torres Celestiales en *Orna: The GPS RPG* y *Hero of Aethric*.

Conexiones:
- Nodo Padre: [[00 - Nodo Central (MOC) - LastCodex]]
- Módulo: [[Módulo Torres Celestiales]]
- Vista Consumidora: [[TowersPage - Torres Celestiales]]
- Servicios Hermanos: [[NotificationsService]], [[CodexService]]

---

## 🧮 Lógica de Cálculo de Pisos

Las torres celestiales operan con un ciclo predecible basado en la época cronológica del juego:
1. **Época de Referencia**:
   - Fecha ancla fijada según la rotación oficial del servidor.
   - Cada ciclo dura exactamente un intervalo de horas definido (rotaciones semanales/bisemanales con saltos de piso por checkpoint).
2. **Piso Máximo (Cap)**:
   - El tope de altura de cualquier torre es el **Piso 50** (`50F`).
   - Al alcanzar el piso 50, se activa la condición `isMaxFloor: true`.
3. **Crecimiento de Pisos por Reseteo (Floor Progression)**:
   - El servicio proyecta la secuencia de ascensos futuros por cada reseteo hasta llegar a 50 pisos mediante `getTowerResetProgression(kind, lang)`.

---

## 🌊 Métodos Principales

| Método | Retorno | Descripción |
| :--- | :--- | :--- |
| `getTowers(lang)` | `TowerInfo[]` | Devuelve el estado actual de las 5 torres (pisos, progreso porcentual, fecha del próximo piso 50, etc.). |
| `getTowerResetProgression(kind, lang)` | `TowerResetProgression[]` | Genera la lista cronológica detallada de cuándo y a qué hora cada torre aumentará de piso en los próximos reseteos. |
| `getNext50Timeline(lang, limit)` | `CheckpointProjection[]` | Proyecta un resumen de los próximos hitos temporales donde alguna torre tocará el piso 50. |
| `getCodexTitanSlug(kind)` | `string` | Devuelve el identificador/slug exacto del titán en el Códice (ej: `titan-selene`) para navegación directa. |

---

## 🔗 Sinapsis Relacionadas
- Ver módulo de torres: [[Módulo Torres Celestiales]]
- Ver vista de torres: [[TowersPage - Torres Celestiales]]
- Ver notificaciones: [[NotificationsService]]
- Ver códice: [[CodexService]]
