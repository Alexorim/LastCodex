---
title: "ProofsService - Lógica de Conversión de Pruebas y Gremios"
type: service
tags:
  - "#servicio"
  - "#proofs"
  - "#typescript"
  - "#calculos"
status: active
version: 1.4.6
created: 2026-09-29
---

# ⚙️ ProofsService — Servicio de Cálculo de Pruebas y Materiales

El `ProofsService` (`src/app/services/proofs.service.ts`) encapsula toda la base de datos de monedas de gremios, el filtrado estricto de materiales de artesanía del Códice, y las fórmulas oficiales de conversión matemática bidireccional.

Conexiones:
- Nodo Padre: [[00 - Nodo Central (MOC) - LastCodex]]
- Módulo: [[Módulo Calculadora de Pruebas de Gremios]]
- Consumidor Principal: [[ProofsPage - Calculadora de Pruebas]]
- Fuente de Datos: [[CodexService]] y `codex-items.json`

---

## 🏗️ Métodos Principales

### 1. `initMaterials(): void`
Filtra estrictamente los ítems del Códice (`item.subcategory === 'material' || item.category === 'materials'`) para descartar armas, armaduras o consumibles. Genera la caché en memoria deduplicada por `id`/`nameEn`.

### 2. `calculateBaseRate(tier: number, rarity?: string): number`
Calcula la tasa base con la fórmula oficial:
```typescript
const mult = RARITY_MULTIPLIER[rarity] ?? 0;
return tier * 10 + mult * 5;
```

### 3. `calculateProofCost(materialCount: number, currencyRate: number, baseRate: number): number`
Calcula el coste de pruebas redondeando siempre hacia arriba (`Math.ceil`):
```typescript
Math.ceil((materialCount * currencyRate * baseRate) / 100);
```

### 4. `calculateMaterialCountFromProof(proofCount: number, currencyRate: number, baseRate: number): number`
Calcula la cantidad de materiales que se pueden comprar dado un saldo de pruebas (`Math.floor`):
```typescript
Math.floor((proofCount * 100) / (currencyRate * baseRate));
```

### 5. `calculateAll(materialCount: number, baseRate: number): ProofCalculationResult[]`
Aplica el cálculo simultáneo sobre todas las monedas registradas en `PROOF_CURRENCIES` devolviendo la lista completa formateada.

### 6. `getCurrencies(): ProofCurrency[]`
Devuelve el catálogo maestro de monedas con sus íconos, ratios, nombres bilingües y colores de acento.
