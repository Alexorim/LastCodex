---
title: "TowersPage - Torres Celestiales"
type: page
tags:
  - "#pagina"
  - "#vista"
  - "#torres"
  - "#celestial"
version: 1.4.5
created: 2026-09-29
---

# 🗼 TowersPage — Torres Celestiales (`towers.page.ts`)

`TowersPage` proporciona a la comunidad una interfaz visual para supervisar las 5 torres celestiales, la cuenta regresiva hacia el próximo reseteo, la altura actual de cada torre y la programación de alertas al piso 50.

Conexiones:
- Nodo Padre: [[00 - Nodo Central (MOC) - LastCodex]]
- Módulo: [[Módulo Torres Celestiales]]
- Servicios Inyectados: [[TowersService]], [[NotificationsService]], [[CodexService]], [[SettingsService]]
- Vistas Relacionadas: [[CodexPage - Explorador del Códice]], [[SettingsPage - Configuración]]

---

## 🧭 Interacción y Componentes de la Vista

1. **Tarjetas de Torres**:
   - Tarjeta estilizada con el sprite y arte del titán.
   - Indicador de pisos actuales (`X / 50 Pisos`) con barra de progreso porcentual.
   - Cuenta atrás para el siguiente aumento de pisos o reseteo.
   - Botón de recordatorio para notificar en el celular cuando la torre alcance los 50 pisos.
2. **Modal de Crecimiento de Pisos (Floor Growth Modal)**:
   - Al pulsar sobre el titán o la tarjeta de la torre, se despliega un modal interactivo.
   - Muestra la proyección de pisos durante los futuros reseteos (cuántos pisos aumentará y en qué fechas/horas exactas).
3. **Acceso Directo al Códice**:
   - Botón *"Ver en el códice"* dentro de la tarjeta o modal que redirige directamente al jugador a la ficha oficial de ese Titán dentro de [[CodexPage - Explorador del Códice]], abriendo su modal detallado sin necesidad de buscarlo manualmente.
4. **Diseño Visual Depurado**:
   - Eliminación de textos de afinidad elemental redundantes para una experiencia limpia y centrada en la información táctica de farmeo.

---

## 🔗 Sinapsis Relacionadas
- Ver servicio de torres: [[TowersService]]
- Ver servicio de notificaciones: [[NotificationsService]]
- Ver módulo de torres: [[Módulo Torres Celestiales]]
- Ver explorador del códice: [[CodexPage - Explorador del Códice]]
