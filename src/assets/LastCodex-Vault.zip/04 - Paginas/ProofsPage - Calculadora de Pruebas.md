---
title: "ProofsPage - Calculadora de Pruebas y Materiales"
type: page
tags:
  - "#pagina"
  - "#proofs"
  - "#ui"
  - "#mobile"
status: active
version: 1.4.6
created: 2026-09-29
---

# 📱 ProofsPage — Interfaz de la Calculadora de Pruebas

`ProofsPage` (`src/app/pages/proofs/proofs.page.ts`) es la interfaz de usuario donde los jugadores interactúan con la calculadora de gremios. Ha sido diseñada con un enfoque prioritario en la experiencia móvil (*Mobile-First*).

Conexiones:
- Nodo Padre: [[00 - Nodo Central (MOC) - LastCodex]]
- Módulo: [[Módulo Calculadora de Pruebas de Gremios]]
- Servicio: [[ProofsService]]
- Enlace de Acceso: [[HomePage - Forecast Hoy y Mañana]] (Junto a Eventos)

---

## 🎨 Componentes Visuales

1. **Encabezado (`ion-toolbar`)**:
   - Botón de retroceso al flujo anterior.
   - Título con ícono `calculator-outline`.
   - Botón de enlace directo a la vista del Códice (`book-outline`).

2. **Banner Introductorio (`.calc-intro-card`)**:
   - Muestra la explicación de conversor de gremios en computadoras de escritorio.
   - **Auto-ocultación en móvil** (`@media (max-width: 600px)`): Se oculta para no ocupar espacio vertical valioso en teléfonos celulares.

3. **Cabecera Unificada de Controles (`.unified-calc-header`)**:
   - Agrupa el selector de material y el control de cantidad en una sola fila integrada de dos columnas en escritorio.
   - En pantallas móviles (`@media (max-width: 600px)`), se apilan verticalmente con el material arriba y la cantidad abajo, ambos al 100% de ancho.

4. **Selector de Material (`.material-selection-box`)**:
   - **Estado Vacío (`.empty-material-card`)**: Muestra un slot estilizado con halo punteado, ícono `+` y botón lupa "Buscar" que previene cualquier desborde horizontal.
   - **Estado Activo (`.selected-material-card`)**: Muestra el sprite del material, su nombre en inglés y español, tier, rareza y botón de ficha en Códice.
   - **Panel Desplegable (`.material-picker-panel`)**: Barra de búsqueda con filtrado en tiempo real sin botones de tier redundantes.

5. **Entrada de Cantidad (`.quantity-input-box`)**:
   - Input centrado grande (`.large-input-wrap`) para ingresar directamente la cantidad deseada de materiales sin controles distractores.
   - En escritorio, mantiene un ancho compacto estilizado (`max-width: 240px`).

6. **Cuadrícula de Resultados en Gremios (`.proofs-grid.two-cols-grid`)**:
   - Distribución exacta de **2 tarjetas por columna**.
   - **Adaptabilidad Desktop / Móvil**: En computadoras restaura y muestra el nombre oficial del gremio (`.guild-title-desktop`) para mayor legibilidad; en dispositivos móviles oculta el título largo y preserva las mini tarjetas compactas enfocadas en el logo, ratio y número de pruebas requeridas.
