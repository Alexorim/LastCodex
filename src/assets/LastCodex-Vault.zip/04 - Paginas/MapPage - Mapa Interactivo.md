---
title: "MapPage - Mapa Interactivo"
type: page
tags:
  - "#pagina"
  - "#vista"
  - "#mapa"
  - "#ciudades"
version: 1.4.5
created: 2026-09-29
---

# 🗺️ MapPage — Mapa Interactivo (`map.page.ts`)

`MapPage` es el visor cartográfico interactivo de **LastResources**, diseñado para ofrecer navegación fluida sobre el mapa de los reinos de *Aethric* y *Orna*.

Conexiones:
- Nodo Padre: [[00 - Nodo Central (MOC) - LastCodex]]
- Módulo: [[Módulo Mapa Interactivo de Ciudades y Marcadores]]
- Ajustes y Acceso: [[SettingsPage - Configuración]]

---

## 🧭 Características de la Pantalla

1. **Visor de Pantalla Completa**:
   - Diseño inmersivo sin encabezados flotantes invasivos, optimizando el área útil en pantallas móviles y monitores de escritorio.
2. **Botón HUD de Filtros con Popover Flotante**:
   - Ubicado estratégicamente junto a la barra de controles para no entorpecer la vista.
   - Permite alternar capas de marcadores: Ciudades, Mazmorras, Santuarios y Puntos de Encuentro.
3. **Filtro Inicial Optimizado**:
   - Al abrir la página del mapa, únicamente el filtro de **Ciudades** está activo (`ciudades = true`), mientras que los filtros de mazmorras y otros puntos densos arrancan desactivados para garantizar fluidez inmediata y rendimiento estable.
4. **Escalado Dinámico de Iconos**:
   - Los iconos de ciudades y puntos se escalan inteligentemente con el zoom para que se mantengan perfectamente reconocibles desde cualquier distancia de cámara.

---

## 🔗 Sinapsis Relacionadas
- Ver módulo de mapa: [[Módulo Mapa Interactivo de Ciudades y Marcadores]]
- Ver panel de ajustes: [[SettingsPage - Configuración]]
