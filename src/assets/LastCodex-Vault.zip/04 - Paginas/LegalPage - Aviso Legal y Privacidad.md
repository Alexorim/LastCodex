---
title: "LegalPage - Aviso Legal y Privacidad"
type: page
tags:
  - "#pagina"
  - "#vista"
  - "#legal"
  - "#privacidad"
  - "#dmca"
version: 1.4.5
created: 2026-09-29
---

# ⚖️ LegalPage — Aviso Legal y Privacidad (`legal.page.ts`)

`LegalPage` es la página de transparencia jurídica y protección de la plataforma, que establece formalmente los términos de uso, descargo de responsabilidad, política de no recopilación de datos personales y el canal de atención DMCA.

Conexiones:
- Nodo Padre: [[00 - Nodo Central (MOC) - LastCodex]]
- Módulo: [[Módulo Legal y Cumplimiento DMCA]]
- Accesos: Footer de navegación y [[SettingsPage - Configuración]]

---

## 📜 Secciones Principales

1. **Aviso de Proyecto de Fans Sin Fines de Lucro**:
   - Declaración de herramienta gratuita desarrollada por la comunidad para facilitar el seguimiento de eventos y pronósticos.
2. **Marcas Comerciales y Propiedad Intelectual**:
   - Reconocimiento explícito de que *Orna: The GPS RPG* y *Hero of Aethric* son marcas registradas de **Northern Forge Studios**.
   - Aclaración de no afiliación comercial ni patrocinio oficial por parte de la desarrolladora.
3. **Uso de Datos Públicos**:
   - Declaración de que la base de datos del códice utiliza datos abiertos y accesibles públicamente con propósitos puramente estadísticos y formativos.
4. **Política de Privacidad Estricta**:
   - Declaración formal de que la aplicación **no recopila datos de carácter personal**, no implementa rastreadores de comportamiento publicitario ni almacena cookies con fines de lucro.
5. **Procedimiento DMCA / Retiro de Contenido**:
   - Publicación formal de la dirección de contacto para solicitudes de retirada conforme a la DMCA: `guygamerxd@gmail.com`.

---

## 🔗 Sinapsis Relacionadas
- Ver módulo legal: [[Módulo Legal y Cumplimiento DMCA]]
- Ver ajustes: [[SettingsPage - Configuración]]
- Ver códice: [[CodexPage - Explorador del Códice]]
