---
title: "Registro de Actualizaciones (Changelog Maestro)"
type: update-hub
tags:
  - "#hub"
  - "#actualizacion"
  - "#changelog"
  - "#versiones"
version: 1.4.5
created: 2026-09-23
updated: 2026-09-29
---

# 📜 Registro de Actualizaciones (Changelog Maestro)

Bienvenido al nodo central de **control evolutivo y versiones** de **LastResources** (anteriormente *LastCodex*). Este módulo documenta la historia completa de desarrollo, las transformaciones arquitectónicas, correcciones de errores y nuevas funcionalidades introducidas a lo largo de cada hito de versión.

Conexiones:
- Nodo Padre: [[00 - Nodo Central (MOC) - LastCodex]]
- Resumen General: [[02 - Versiones y Changelog]]
- Protocolo de Nuevas Versiones: [[Plantilla de Nueva Versión]]

```
                                [Changelog Maestro]
                                         │
        ┌────────────────┬───────────────┴───────────────┬────────────────┐
        ▼                ▼                               ▼                ▼
 ┌─────────────┐  ┌─────────────┐                 ┌─────────────┐  ┌─────────────┐
 │   v1.0.0    │  │   v1.2.0    │                 │   v1.4.0    │  │   v1.4.5    │
 │ (Fundación) │  │ (OfflineDB) │                 │(Multilingüe)│  │  (Actual)   │
 └─────────────┘  └─────────────┘                 └─────────────┘  └─────────────┘
```

---

## 🧭 Hitos de Versión en la Red

| Versión | Nombre Clave | Estado | Fecha de Corte | Commits Clave |
| :--- | :--- | :--- | :--- | :--- |
| **[[v1.4.5 - Rebranding LastResources, Torres Celestiales, Notificaciones Push y Blindaje Legal]]** | *LastResources & Torres* | **Actual (Producción)** | 27 Septiembre 2026 | `03edada`, `e2b7b27`, `38fa794`, `9dafe90` |
| **[[v1.4.4 - Visor de Mapa Interactivo y Comprobador de Actualizaciones Remoto]]** | *Mapa & Update Checker* | Precedente | 25 Septiembre 2026 | `27c9495`, `014f7ee`, `8b4de09`, `5250d0f` |
| **[[v1.4.3 - Nombre Estable APK, Glassmorphism Sakura y Soporte Notch]]** | *APK Estable & Notch* | Precedente | 24 Septiembre 2026 | `1d0efb2`, `210ce6d` |
| **[[v1.4.2 - Tema Sakura, Footer Compacto y Auto-ocultación de Barra]]** | *Tema Sakura & Auto-BNB* | Precedente | 24 Septiembre 2026 | `8e0a716`, `7d10fb6` |
| **[[v1.4.1 - Efecto Glassmorphism en Sprite Codex, Paleta Café y Corrección Tema Claro]]** | *Glassmorphism & Paleta Café* | Precedente | 23 Septiembre 2026 | `ca7affc`, `bdd3023` |
| **[[v1.4.0 - Tema Claro, 22 Idiomas, Ajuste de Grilla Codex y Limpieza de Barra]]** | *Tema Claro & 22 Idiomas* | Precedente | Septiembre 2026 | `v1.4.0` |
| **[[v1.3.1 - Paginación Numérica y Modo Cuadrícula en Códice]]** | *Paginación & Vista Cuadrícula* | Precedente | Septiembre 2026 | `d1389bd` |
| **[[v1.3.0 - Renacimiento LastCodex, Subcategorías y APK Versionada]]** | *Branding & Subcategorías* | Precedente | Septiembre 2026 | `14039c3`, `dd3d54f`, `998984e`, `c2d471c` |
| **[[v1.2.0 - Códice Masivo Offline (5065 ítems) y Sincronización]]** | *Offline IndexedDB & Sync* | Precedente | Septiembre 2026 | `c041b4e`, `38d628a`, `82c28f0`, `41eded1` |
| **[[v1.1.0 - Clases, Eventos, Canvas Offline y Soporte Android]]** | *Expansión de Funcionalidades* | Precedente | Septiembre 2026 | `1d39d71`, `7e9b8d7`, `158f6bc`, `27e4d69` |
| **[[v1.0.0 - Lanzamiento Inicial Orna Guild Forecast y Multiplataforma]]** | *Génesis del Proyecto* | Fundación | Agosto 2026 | `6ea2411`, `1793c8a`, `417b2ab`, `fb28397` |

---

## 📈 Resumen Evolutivo por Capas del Sistema

### 🎨 Capa Visual & Branding
- `v1.0.0`: Lanzamiento inicial con tema básico de forecast.
- `v1.3.0`: Transición de marca a LastCodex, logos con transparencia y *pills* de subcategorías.
- `v1.4.0`: Tema claro pergamino y soporte para 22 idiomas.
- `v1.4.1`: Glassmorphism en tarjetas de sprites de códice y paleta café (#2A2826).
- `v1.4.2`: Nuevo tema Sakura y auto-ocultación de barra inferior al scrollear hacia el pie.
- `v1.4.3`: Glassmorphism Sakura y soporte de safe-area notch.
- `v1.4.4`: Visor de mapa cartográfico interactivo de pantalla completa con filtro HUD flotante.
- `v1.4.5`: Rebranding definitivo a **LastResources**, tarjetas tácticas de Torres Celestiales y eliminación de textos superfluos.

### 📱 Capa de Notificaciones y Sistema Móvil
- `v1.1.0`: Soporte nativo Android con Capacitor.
- `v1.3.0`: Compilador automatizado de APKs.
- `v1.4.3`: Binario estable unificado `lastcodex_stable.apk`.
- `v1.4.4`: Verificador de actualizaciones en vivo mediante endpoint remoto en Vercel.
- `v1.4.5`: Integración de `@capacitor/local-notifications`, recordatorios a la barra de estado para materiales y aviso de Torres al Piso 50. Identificador nativo `com.lastresources.app`.

### ⚖️ Capa Jurídica y Transparencia
- `v1.4.5`: Marco de cumplimiento Safe Harbor / DMCA (`guygamerxd@gmail.com`), reconocimiento explícito de derechos a *Northern Forge Studios*, política estricta de cero recolección de datos personales y página `/legal`.

---

## 🔗 Sinapsis Relacionadas
- Volver al MOC: [[00 - Nodo Central (MOC) - LastCodex]]
- Ver detalles de la versión activa: [[02 - Versiones y Changelog]]
- Ver script de compilación: [[Script Build APK]]
